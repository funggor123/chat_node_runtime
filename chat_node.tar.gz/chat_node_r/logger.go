package main

/*
Keep logging of all the operations
*/
import (
	"fmt"
	"log"
	"os"
)

type LoggerInterface interface {
	stdPrint(level int, a ...interface{})
	writeAtLog(level int, a ...interface{})
	setLogFilePath(path string)
}

type Logger struct {
	logFileNameAndPath string
	logLevel           int
}

var DEBUG_MSG_ERROR = "(Error)"
var DEBUG_MSG_TRACK = "(Track)"

const (
	SHOW_ERROR_AND_TRACK = iota
	SHOW_TRACK           = iota
)

const (
	ERROR = iota
	TRACK = iota
)

var logger *Logger

func getLogger() *Logger {
	if logger == nil {
		logger = new(Logger)
	}
	return logger
}

/*
Set Log File Path
*/
func (logger *Logger) setLogFilePath(filePath string) {
	logger.logFileNameAndPath = filePath + getCurrentTimeInRFC() + ".log"
}

/*
Print the log in standard output
*/
func (logger Logger) stdPrint(level int, a ...interface{}) {
	switch logger.logLevel {
	case SHOW_ERROR_AND_TRACK:
		if level == TRACK {
			fmt.Print(DEBUG_MSG_TRACK)
		} else if level == ERROR {
			fmt.Print(DEBUG_MSG_ERROR)
		}
		fmt.Print(" : ")
		fmt.Println(a)
	case SHOW_TRACK:
		if level == TRACK {
			fmt.Print(DEBUG_MSG_TRACK)
			fmt.Print(" : ")
			fmt.Println(a)
		}
	}
}

func (logger Logger) log(level int, a ...interface{}) {
	logger.stdPrint(level, a)
	logger.writeAtLog(level, a)
}

/*
Write to logs to log file
*/
func (logger Logger) writeAtLog(level int, a ...interface{}) {
	f, err := os.OpenFile(logger.logFileNameAndPath, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)
	if err != nil {
		logger.stdPrint(ERROR, "Unable to open the log file")
		logger.stdPrint(ERROR, "Exit the program")
		os.Exit(3)
	}
	defer f.Close()
	log.SetOutput(f)
	switch logger.logLevel {
	case SHOW_ERROR_AND_TRACK:
		if level == TRACK {
			log.Print(DEBUG_MSG_TRACK, ":", a)
		} else if level == ERROR {
			log.Print(DEBUG_MSG_ERROR, ":", a)
		}
	case SHOW_TRACK:
		if level == TRACK {
			log.Print(DEBUG_MSG_TRACK, ":", a)
		}
	}
}
