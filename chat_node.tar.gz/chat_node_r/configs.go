package main

import (
	"encoding/json"
	"os"
)

type Configuration struct {
	Port        string `json:"port" binding:"required"`
	LogFilePath string `json:"log_file_path" binding:"required"`
}

type ConfigureInterface interface {
	readConfigs() error
	printConfigs()
}

type Configure struct {
	config Configuration
}

var CONFIG_JSON_STRING = "conf.json"

var configure *Configure

func getConfigure() *Configure {
	if configure == nil {
		configure = new(Configure)
	}
	return configure
}

func (configure *Configure) readConfigs() error {
	file, _ := os.Open(CONFIG_JSON_STRING)
	defer file.Close()
	decoder := json.NewDecoder(file)
	configuration := Configuration{}
	err := decoder.Decode(&configuration)
	if err != nil {
		getLogger().stdPrint(ERROR, err)
		return err
	}

	// Copying
	configure.config.LogFilePath = configuration.LogFilePath
	configure.config.Port = configuration.Port

	// Set the Log file Path
	getLogger().setLogFilePath(getConfigure().config.LogFilePath)
	configure.printConfigs()

	return nil
}

func (configure Configure) printConfigs() {
	if &configure.config != nil {
		getLogger().log(TRACK, "------------Configurations of Chat Node-------------")
		getLogger().log(TRACK, "Host Port: ", configure.config.Port)
		getLogger().log(TRACK, "LogFilePathAndName: ", configure.config.LogFilePath)
		getLogger().log(TRACK, "----------------------------------------------------")
	}
}
