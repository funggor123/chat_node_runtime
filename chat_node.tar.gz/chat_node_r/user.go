package main

import (
	"encoding/json"
	"net/http"

	"labix.org/v2/mgo/bson"
)

var UserTable = "user"

type User struct {
	Id          bson.ObjectId `bson:"_id"`
	NickName    string        `bson:"nick_name"`
	UserAddress string        `bson:"user_address"`
}

type RegisterHttpResponse struct {
	User_address string `json:"user_address"`
	Nick_name    string `json:"nick_name"`
}

// Register User Handler

func registerUserHandler(w http.ResponseWriter, r *http.Request) {
	keys := r.URL.Query()
	nick_name := keys.Get("nick_name")

	user_address, err := createUserInDB(nick_name)
	if err != nil {
		getLogger().log(TRACK, nick_name, "-> register fial")
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	response := RegisterHttpResponse{User_address: user_address, Nick_name: nick_name}
	js, err := json.Marshal(response)
	if err != nil {
		getLogger().log(ERROR, err)
		getLogger().log(TRACK, nick_name, "-> register fial")
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	getLogger().log(TRACK, nick_name, "-> register success user_address ->", user_address)
	w.WriteHeader(200)
	w.Header().Set("Content-Type", "application/json")
	w.Write(js)
}

// Authenticate using the userID

func authenticate(userID string) (User, bool) {
	users, err := findUserInDB(userID)
	if err != nil {
		return User{}, false
	}
	if len(users) == 0 {
		getLogger().log(TRACK, "Cannot find the user_id in DB")
		return User{}, false
	}
	return users[0], true
}

// Find User in Mongodb

func findUserInDB(userAddress string) ([]User, error) {

	userCollection, session, err := getCollection(UserTable, NAME_DB)
	defer session.Close()
	if err != nil {
		getLogger().log(ERROR, err)
		session.Close()
		return nil, err
	}
	var users []User
	userCollection.Find(bson.M{"user_address": userAddress}).All(&users)
	return users, nil
}

// Create a User in mongodb

func createUserInDB(nickName string) (string, error) {

	userCollection, session, err := getCollection(UserTable, NAME_DB)
	defer session.Close()
	if err != nil {
		getLogger().log(ERROR, err)
		session.Close()
		return "", err
	}
	newid := bson.NewObjectId()
	UserAddress := RandStringRunes(5)
	user := User{Id: newid, NickName: nickName, UserAddress: UserAddress}
	err = userCollection.Insert(user)
	if err != nil {
		getLogger().log(ERROR, err)
		session.Close()
		return "", err
	}
	return UserAddress, nil
}
