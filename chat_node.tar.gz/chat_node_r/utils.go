package main

import (
	"math/rand"
	"time"
)

var letterRunes = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")

func RandStringRunes(n int) string {
	b := make([]rune, n)
	for i := range b {
		b[i] = letterRunes[rand.Intn(len(letterRunes))]
	}
	return string(b)
}

func getCurrentTime() string {
	current_time := time.Now().Local()
	timeString := current_time.Format("Mon Jan _2 15:04:05 2006")
	return timeString
}

func getCurrentTimeInRFC() string {
	return time.Now().Format("2006-01-02T15:04:05")
}
